MATOVU MARTIN — CREATIVE MEDIA WEBSITE

FILES
- index.html: website content and structure
- style.css: colours, layout and responsive styling
- script.js: mobile menu, portfolio filters and contact form

HOW TO OPEN
1. Extract this ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. If you have the Live Server extension, right-click index.html and choose "Open with Live Server".
   Otherwise, double-click index.html to open it in your browser.

IMPORTANT CUSTOMISATION
- The portfolio cards are starter design concepts, not photographs of completed client projects.
- Replace the sample portfolio visuals with your own project images when ready.
- The contact form currently prepares an email to matovum614@gmail.com. Change this in script.js if needed.
- Google Fonts are loaded online; the site still works without them using fallback fonts.

PUBLISHING
You can publish the website free using GitHub Pages or Netlify after you have checked it on your computer.
